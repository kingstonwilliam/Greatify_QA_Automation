package pageObject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class InboxMsgObject {
		   @FindBy(xpath = "/html/body/div[7]/div[3]/div/div[2]/div[2]/div/div/div/div[2]/div/div[1]/div/div/div/div/div/div[2]/div[6]/div[1]/div/table/tbody/tr")
		   public static WebElement ClickInboxMsg;
		}


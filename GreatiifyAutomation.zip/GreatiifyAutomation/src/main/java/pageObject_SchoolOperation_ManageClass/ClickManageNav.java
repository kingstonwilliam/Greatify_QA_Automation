package pageObject_SchoolOperation_ManageClass;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClickManageNav {
	@FindBy(xpath = "/html/body/div[1]/nav/div[1]/div/ul/li[2]/ul/li[2]/a/span")
	public static WebElement ClickNavManageClassBtn;

	

}

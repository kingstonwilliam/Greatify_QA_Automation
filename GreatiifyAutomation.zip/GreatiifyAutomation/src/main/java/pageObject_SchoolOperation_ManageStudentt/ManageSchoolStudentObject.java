package pageObject_SchoolOperation_ManageStudentt;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ManageSchoolStudentObject {
	@FindBy(xpath = "//*[@id=\"sideStudent\"]/a/span")
public static WebElement ClickManageSchoolStudent;
	


























;
}

package pageObject_TransportManagement;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ManageTransport {
@FindBy(xpath = "//*[@id=\"fleetManagementSection\"]/p")	
public static WebElement TransportManagement;
@FindBy(xpath = "//*[@id=\"sideManageTransport\"]/a/span")	
public static WebElement ClickManageTransport;
@FindBy(xpath = "//*[@id=\"pills-home\"]/div[1]/div[2]/button[2]")	
public static WebElement AddVehicle;
@FindBy(xpath = "/html/body/div[3]/main/div[2]/div[5]/div[3]/div[1]/div[2]/div[1]/label/input")	
public static WebElement EnterVehicleId;
@FindBy(xpath = "//*[@id=\"name17\"]")
public static WebElement RegistrationNumber;
@FindBy(xpath = "//*[@id=\"name18\"]")	
public static WebElement VehicleBoughtOn;
@FindBy(xpath = "/html/body/div[3]/main/div[2]/div[5]/div[3]/div[1]/div[2]/div[4]/label/input")	
public static WebElement VehicleAge;
@FindBy(xpath = "//*[@id=\"add_vehicle_set\"]/div[3]/div[1]/div[2]/div[5]/select/option[2]")	
public static WebElement ChooseManufacturer;
@FindBy(xpath = "//*[@id=\"name20\"]")	
public static WebElement VehicleModel;
@FindBy(xpath = "//*[@id=\"name21\"]")	
public static WebElement VehicleGps;
@FindBy(xpath = "/html/body/div[3]/main/div[2]/div[5]/div[3]/div[1]/div[2]/div[8]/label/input")	
public static WebElement VehicleTotalCapacity;
@FindBy(xpath = "/html/body/div[3]/main/div[2]/div[5]/div[3]/div[2]/div[2]/div[1]/div[1]/label/input")	
public static WebElement FcNo;
@FindBy(xpath = "//*[@id=\"name23\"]")	
public static WebElement FcStartDate;
@FindBy(xpath = "//*[@id=\"name24\"]")	
public static WebElement FcEndDate;
@FindBy(xpath = "//*[@id=\"name25\"]")	
public static WebElement TotalFcDone;
@FindBy(xpath = "//*[@id=\"name26\"]")	
public static WebElement InsuranceNo;
@FindBy(xpath = "//*[@id=\"name27\"]")	
public static WebElement CurrentInsuranceStartDate;
@FindBy(xpath = "//*[@id=\"name28\"]")	
public static WebElement CurrentInsuranceEndDate;
@FindBy(xpath = "/html/body/div[3]/main/div[2]/div[5]/div[3]/div[2]/div[2]/div[5]/div/div[1]/label/p")	
public static WebElement UploadDocument1;
@FindBy(xpath="/html/body/div[3]/main/div[2]/div[5]/div[3]/div[2]/div[2]/div[5]/div/div[2]/label/p")	
public static WebElement UploadDocument2;
@FindBy(xpath = "/html/body/div[3]/main/div[2]/div[5]/div[3]/div[2]/div[2]/div[5]/div/div[3]/label/p")	
public static WebElement UploadDocument3;
@FindBy(xpath = "/html/body/div[3]/main/div[2]/div[5]/div[3]/div[2]/div[2]/div[5]/div/div[4]/label/p")	
public static WebElement UploadDocument4;
@FindBy(xpath = "/html/body/div[3]/main/div[2]/div[5]/div[3]/div[2]/div[2]/div[6]/div[2]/div[1]/label/p")	
public static WebElement UploadDocument5;
@FindBy(xpath = "/html/body/div[3]/main/div[2]/div[5]/div[3]/div[2]/div[2]/div[6]/div[2]/div[2]/label/p")	
public static WebElement UploadDocument6;
@FindBy(xpath = "/html/body/div[3]/main/div[2]/div[5]/div[3]/div[2]/div[2]/div[6]/div[2]/div[3]/label/p")	
public static WebElement UploadDocument7;
@FindBy(css = "body > div.swal-overlay.swal-overlay--show-modal > div > div.swal-footer > div > button")
public static WebElement ImgUploadSuccess;
@FindBy(xpath = "//*[@id=\"add_vehicle_set\"]/div[3]/div[2]/div[2]/div[7]/button")
public static WebElement ClickAddVehicle;
@FindBy(css = "body > div.swal-overlay.swal-overlay--show-modal > div > div.swal-footer > div > button")
public static WebElement VehicleSuccessMsg;
//CLICK ROUTE AND ADD ROUTE
@FindBy(xpath = "/html/body/div[3]/main/div[2]/div[1]/div[2]/ul/li[2]/button")
public static WebElement AddRoute;
@FindBy(xpath = "//*[@id=\"pills-table\"]/div[1]/div[2]/div[2]/button")
public static WebElement CreateAddRoute;
@FindBy(xpath = "//*[@id=\"add_route\"]/div/div/div[2]/div/div[1]/div[1]/input")
public static WebElement RouteName;
@FindBy(xpath = "//*[@id=\"add_route\"]/div/div/div[2]/div/div[1]/div[2]/select/option[2]")
public static WebElement ChooseBus;
@FindBy(xpath = "//*[@id=\"add_route\"]/div/div/div[2]/div/div[1]/div[3]/label/input")
public static WebElement TripStartTime;
@FindBy(xpath = "//*[@id=\"add_route\"]/div/div/div[2]/div/div[1]/div[5]/input")
public static WebElement StartingPoint;
@FindBy(xpath = "//*[@id=\"add_route\"]/div/div/div[2]/div/div[1]/div[6]/input")
public static WebElement EndingPoint;
@FindBy(xpath = "//*[@id=\"add_route\"]/div/div/div[2]/div/div[1]/div[7]/select/option[2]")
public static WebElement Driver;
@FindBy(xpath = "//*[@id=\"add_route\"]/div/div/div[2]/div/div[1]/div[8]/select/option[3]")
public static WebElement CareTaker;
@FindBy(xpath = "//*[@id=\"add_route\"]/div/div/div[2]/div/div[1]/div[10]/div/input")
public static WebElement FeeAmount;
@FindBy(xpath = "//*[@id=\"add_route\"]/div/div/div[2]/div/div[3]/div[1]/input")
public static WebElement Location;
@FindBy(xpath = "//*[@id=\"add_route\"]/div/div/div[2]/div/div[3]/div[2]/input")
public static WebElement ArrivingTime;
@FindBy(xpath = "//*[@id=\"add_route\"]/div/div/div[3]/button[2]")
public static WebElement Fee;
@FindBy(xpath = "//*[@id=\"add_route\"]/div/div/div[2]/div/div[3]/div[4]/span/i")
public static WebElement Gps;
@FindBy(xpath = "//*[@id=\"searchId\"]")
public static WebElement ClickSearch;
@FindBy(xpath="//*[@id=\"myModal\"]/div/div/div[3]/button")
public static WebElement ClickSubmitBtn;
@FindBy(xpath = "//*[@id=\"add_route\"]/div/div/div[3]/button[2]")
public static WebElement SubmitBtn;
@FindBy(css = "body > div.swal-overlay.swal-overlay--show-modal > div > div.swal-footer > div > button")
public static WebElement SuccessBtn;
//Student Mapping
@FindBy(xpath = "/html/body/div[3]/main/div[2]/div[1]/div[2]/ul/li[3]/button")
public static WebElement StudentMapping;
@FindBy(xpath = "//*[@id=\"DataTables_Table_3\"]/tbody/tr/td[8]/a")
public static WebElement ViewStudent;
@FindBy(xpath = "//*[@id=\"assign_student_view\"]/div/div/div[3]/div/div[4]/ul/li[1]/label")
public static WebElement ClickAddStudent;
@FindBy(xpath = "//*[@id=\"student_mapping_view\"]/div[2]/div[2]/button[1]")
public static WebElement SelectStudent;
@FindBy(xpath = "//*[@id=\"vehicle_routes\"]/option[2]")
public static WebElement ChooseLocation;
@FindBy(xpath = "//*[@id=\"assign_student_view\"]/div/div/div[2]/div[2]/button[2]")
public static WebElement AddStudent;
@FindBy(css = "body > div.swal-overlay.swal-overlay--show-modal > div > div.swal-footer > div > button")
public static WebElement AddSuccessMsg;
//Delete Student
@FindBy(css = "#DataTables_Table_7 > tbody > tr > td.delete_text > img")
public static WebElement ClickDeleteLogo;
@FindBy(css = "body > div.swal-overlay.swal-overlay--show-modal > div > div.swal-footer > div:nth-child(2) > button")
public static WebElement ConfirmationMsg;
@FindBy(css = "body > div.swal-overlay.swal-overlay--show-modal > div > div.swal-footer > div > button")
public static WebElement DeleteSuccessMsg;
}


package pageObject_School_DashBoard_Settings;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SettingsAndUserManagement {
	@FindBy()
    public static WebElement ClickSettings;
	@FindBy()
	public static WebElement ClickUserManagement;
	@FindBy()
	public static WebElement ClickUsrRole;
	@FindBy()
	public static WebElement CreateNewUserRole;
	@FindBy()
	public static WebElement EnterUserRoleName;
	@FindBy()
	public static WebElement ChooseLevel;
	@FindBy()
	public static WebElement ClickCheckBox;
	@FindBy()
	public static WebElement ClickCreate;
	@FindBy()
	public static WebElement CreateSuccess;
	//USER ROLE EDIT
	@FindBy()
	public static WebElement ClickEditBtn;
	@FindBy()
	public static WebElement ClickUserName;
	@FindBy()
	public static WebElement ClickCheckBox1;
	@FindBy()
	public static WebElement ClickCheckBox2;
	@FindBy()
	public static WebElement ClickCheckBox3;
	@FindBy()
	public static WebElement ClickUpdate;
	@FindBy()
	public static WebElement ClickSuccessMsg;
	//DELETE USER ROLE
	@FindBy()
	public static WebElement ClickDeleteLogo;
	@FindBy()
	public static WebElement ClickConfirmationMsg;
	@FindBy()
    public static WebElement ClickDeleteSuccess;
	//USER LIST
	public static WebElement ClickClickUserList;
	@FindBy()
	public static WebElement ClickCreateNew;
	@FindBy()
	public static WebElement ClickUserListUserName;
	@FindBy()
	public static WebElement SelectRole;
	@FindBy()
	public static WebElement ClickCreateUsrListbtn;
	@FindBy()
	public static WebElement CreateUserListConfirmationMsg;
	@FindBy()
	public static WebElement UserListSuccess;
	//EDIT USER LIST
	@FindBy()
	public static WebElement ClickEditLogo;
	@FindBy()
	public static WebElement EditUserName;
	@FindBy()
	public static WebElement SelectUserRole;
	@FindBy()
	public static WebElement ClickEditSubmitBtn;
	@FindBy()
	public static WebElement ClickSuccessBtn;
	//DELETE USER LIST
	@FindBy()
	public static WebElement ClickDeleteBtn;
	@FindBy()
	public static WebElement CickDeleteConfirmationMsg;
	@FindBy()
	public static WebElement ClickDeleteSuccessMsg;
}

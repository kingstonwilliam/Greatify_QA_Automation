package testCases_TeacherAndStaffs_CreateTeacher;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import PageObject_TeacherAndStaffs_CreateTeacher.ClickStaffLeaveEntry;
import commonFunction.CommonFunction;

public class TestStaffLeaveEntry extends CommonFunction {

	@Test(priority = 0, dataProvider = "StaffLeaveEntry")
	public void StaffLeaveEntry(String datas) throws InterruptedException, AWTException {
		Robot robot = new Robot();
		String user[] = datas.split(",");
		PageFactory.initElements(driver, ClickStaffLeaveEntry.class);
		Thread.sleep(5000);
		ClickStaffLeaveEntry.ClickStaffLeaveEntry.click();
		Thread.sleep(2000);
		ClickStaffLeaveEntry.ClickAddLeave.click();
		Thread.sleep(2000);
		ClickStaffLeaveEntry.ClickSelectStaff.click();
		Thread.sleep(1000);
		ClickStaffLeaveEntry.ChooseStaff.click();
		ClickStaffLeaveEntry.ChooseLeaveType.click();
		Thread.sleep(1000);
		ClickStaffLeaveEntry.SelectLeaveType.click();
		ClickStaffLeaveEntry.EnterFromDate.click();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_A);
		ClickStaffLeaveEntry.EnterFromDate.sendKeys(user[0]);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_A);
		ClickStaffLeaveEntry.EnterToDate.click();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_A);
		ClickStaffLeaveEntry.EnterToDate.sendKeys(user[1]);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_A);
		ClickStaffLeaveEntry.Reason.click();
		ClickStaffLeaveEntry.Reason.sendKeys(user[2]);
		ClickStaffLeaveEntry.Submit.click();
		Thread.sleep(2000);
		ClickStaffLeaveEntry.SubmitSuccess.click();
	}
	
	@Test(priority=(1),dataProvider = "StaffLeaveEntry")
	public void EditTeachingStaffLeaveEntry(String datas) throws InterruptedException, AWTException {
		Robot robot = new Robot();
		String user[]=datas.split(",");
		PageFactory.initElements(driver, ClickStaffLeaveEntry.class);
		Thread.sleep(2000);
		ClickStaffLeaveEntry.ClickEditLogo.click();
		Thread.sleep(2000);
		ClickStaffLeaveEntry.LeaveType.click();
		Thread.sleep(2000);
//		ClickStaffLeaveEntry.EditFromDate.click();
//		Thread.sleep(1000);
//		ClickStaffLeaveEntry.EditFromDate.clear();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_A);
		ClickStaffLeaveEntry.EditFromDate.sendKeys(user[3]);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_A);
		ClickStaffLeaveEntry.EditToDate.click();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_A);
		ClickStaffLeaveEntry.EditToDate.sendKeys(user[4]);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_A);
		ClickStaffLeaveEntry.EditClickUpdate.click();
		Thread.sleep(2000);
		ClickStaffLeaveEntry.EditSuccess.click();  
		
	}
	@Test(priority=(2))
	public void DeleteStaffEntry() throws InterruptedException {
		PageFactory.initElements(driver, ClickStaffLeaveEntry.class);
		Thread.sleep(2000);
		ClickStaffLeaveEntry.ClickDeleteLogo.click();
		Thread.sleep(2000);
		ClickStaffLeaveEntry.ClickDeleteConfirmationBtn.click();
		Thread.sleep(2000);
		ClickStaffLeaveEntry.DeleteSuccessBtn.click();
	}

	@DataProvider(name = "StaffLeaveEntry")
	public String[] ReadTeacherSettlement() throws IOException, ParseException {
		JSONParser jsonparser = new JSONParser();
		FileReader reader = new FileReader(".\\Jasonfile\\StaffLeaveEntryType.json");
		Object obj = jsonparser.parse(reader);
		JSONObject dashBoardloginObj = (JSONObject) obj;
		JSONArray EmployeeWorkingTimeArray = (JSONArray) dashBoardloginObj.get("LeaveEntryType");
		String arr[] = new String[EmployeeWorkingTimeArray.size()];
		for (int i = 0; i < EmployeeWorkingTimeArray.size(); i++) {
			JSONObject empedit = (JSONObject) EmployeeWorkingTimeArray.get(i);
			String FromDate = (String) empedit.get("FromDate");
			String ToDate = (String) empedit.get("ToDate");
			String Reason = (String) empedit.get("Reason");
			String EditedFromDate = (String) empedit.get("EditedFromDate");
			String EditedChooseDate = (String) empedit.get("EditedChooseDate");
			arr[i] = FromDate + "," + ToDate + "," + Reason + "," + EditedFromDate + "," + EditedChooseDate;
		}
		return arr;
	}
	
		@Test(priority = 3, dataProvider = "NonTeachingStaffLeave")
		public void TestNonTeachingStaffLeaveEntry(String datas) throws InterruptedException, AWTException {
			Robot robot = new Robot();
			String user[] = datas.split(",");
			PageFactory.initElements(driver, ClickStaffLeaveEntry.class);
			Thread.sleep(2000);
			ClickStaffLeaveEntry.ClickAddLeave.click();
			Thread.sleep(2000);
			ClickStaffLeaveEntry.ClickNonteachingCat.click();
		     Thread.sleep(2000);
			ClickStaffLeaveEntry.ClickSelectStaff.click();
			Thread.sleep(1000);
			ClickStaffLeaveEntry.ChooseStaff.click();
			ClickStaffLeaveEntry.ChooseLeaveType.click();
			Thread.sleep(1000);
			ClickStaffLeaveEntry.SelectLeaveType.click();
			ClickStaffLeaveEntry.EnterFromDate.click();
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_A);
			ClickStaffLeaveEntry.EnterFromDate.sendKeys(user[0]);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_A);
			ClickStaffLeaveEntry.EnterToDate.click();
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_A);
			ClickStaffLeaveEntry.EnterToDate.sendKeys(user[1]);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_A);
			ClickStaffLeaveEntry.Reason.click();
			ClickStaffLeaveEntry.Reason.sendKeys(user[2]);
			ClickStaffLeaveEntry.Submit.click();
			Thread.sleep(2000);
			ClickStaffLeaveEntry.SubmitSuccess.click();
			
		}
		@Test(priority = 4,dataProvider ="NonTeachingStaffLeave" )
		public void EditNonTeachingStaff(String datas) throws InterruptedException, AWTException {
			Robot robot = new Robot();
			String user[]=datas.split(",");
			PageFactory.initElements(driver, ClickStaffLeaveEntry.class);
			Thread.sleep(2000);
			ClickStaffLeaveEntry.ClickEditLogo.click();
			Thread.sleep(2000);
			ClickStaffLeaveEntry.LeaveType.click();
			Thread.sleep(2000);
//			ClickStaffLeaveEntry.EditFromDate.click();
//			Thread.sleep(1000);
//			ClickStaffLeaveEntry.EditFromDate.clear();
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_A);
			ClickStaffLeaveEntry.EditFromDate.sendKeys(user[3]);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_A);
			ClickStaffLeaveEntry.EditToDate.click();
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_A);
			ClickStaffLeaveEntry.EditToDate.sendKeys(user[4]);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_A);
			ClickStaffLeaveEntry.EditClickUpdate.click();
			Thread.sleep(2000);
			ClickStaffLeaveEntry.EditSuccess.click(); 
		}
		@Test(priority = (5))
		public void DeleteNonTeachingStaff() throws InterruptedException {
			TestStaffLeaveEntry execute=new TestStaffLeaveEntry();
			Thread.sleep(2000);
			execute.DeleteStaffEntry();
		}
		
	@DataProvider(name = "NonTeachingStaffLeave")
	public String[] ReadStaffLeaveEntry() throws IOException, ParseException {
		JSONParser jsonparser = new JSONParser();
		FileReader reader = new FileReader(".\\Jasonfile\\StaffLeaveEntryType.json");
		Object obj = jsonparser.parse(reader);
		JSONObject dashBoardloginObj = (JSONObject) obj;
		JSONArray EmployeeWorkingTimeArray = (JSONArray) dashBoardloginObj.get("NonTeachingLeaveEntry");
		String arr[] = new String[EmployeeWorkingTimeArray.size()];
		for (int i = 0; i < EmployeeWorkingTimeArray.size(); i++) {
			JSONObject empedit = (JSONObject) EmployeeWorkingTimeArray.get(i);
			String FromDate = (String) empedit.get("FromDate");
			String ToDate = (String) empedit.get("ToDate");
			String Reason = (String) empedit.get("Reason");
			String EditedFromDate = (String) empedit.get("EditedFromDate");
			String EditedChooseDate = (String) empedit.get("EditedChooseDate");
			arr[i] = FromDate + "," + ToDate + "," + Reason + "," + EditedFromDate + "," + EditedChooseDate;
		}
		return arr;
	}
}

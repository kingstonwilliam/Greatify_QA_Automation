package testCases_TransportManagement;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import commonFunction.CommonFunction;
import pageObject_TransportManagement.ManageTransport;

public class ClickNavTransportManagement extends CommonFunction{
       @Test(priority=(0))
	public void clickTransportManagement() throws InterruptedException {
		PageFactory.initElements(driver, ManageTransport.class);
	Thread.sleep(3000);
		ManageTransport.TransportManagement.click();
	}
}

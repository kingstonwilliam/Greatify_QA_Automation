package testCases_TransportManagement;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import commonFunction.CommonFunction;
import pageObject_TransportManagement.ManageTransport;

public class TestManageTransport extends CommonFunction{
	
	@Test(priority = (0),dataProvider = "ManageTransport")
	public void clickManageTransport(String datas) throws InterruptedException, AWTException {
		String Expected ="Manage Transport";
		TestManageTransport execute = new TestManageTransport();
		String user[]=datas.split(",");
		PageFactory.initElements(driver, ManageTransport.class);
		Thread.sleep(5000);
		ManageTransport.ClickManageTransport.click();
//		Thread.sleep(1000);
//        ManageTransport.AddVehicle.click();
//        Thread.sleep(1000);
//        ManageTransport.EnterVehicleId.sendKeys(user[0]);
//        ManageTransport.RegistrationNumber.sendKeys(user[1]);
//        ManageTransport.VehicleBoughtOn.sendKeys(user[2]);
//        ManageTransport.ChooseManufacturer.click();
//        ManageTransport.VehicleModel.sendKeys(user[3]);
//        ManageTransport.VehicleGps.sendKeys(user[4]);
//        ManageTransport.VehicleTotalCapacity.sendKeys(user[5]);
//        ManageTransport.FcNo.sendKeys(user[6]);
//        ManageTransport.FcStartDate.sendKeys(user[7]);
//        ManageTransport.FcEndDate.sendKeys(user[8]);
//        ManageTransport.TotalFcDone.sendKeys(user[9]);
//        ManageTransport.InsuranceNo.sendKeys(user[10]);
//        ManageTransport.CurrentInsuranceStartDate.sendKeys(user[11]);
//        ManageTransport.CurrentInsuranceEndDate.sendKeys(user[12]);
//        ManageTransport.UploadDocument1.click();
//        execute.StudentDocumentUpload();
//        ManageTransport.UploadDocument2.click();
//        execute.StudentDocumentUpload();
//        ManageTransport.UploadDocument3.click();
//        execute.StudentDocumentUpload();
//        ManageTransport.UploadDocument4.click();
//        execute.StudentDocumentUpload();
//        ManageTransport.UploadDocument5.click();
//        execute.StudentDocumentUploadImg();
//        ManageTransport.UploadDocument6.click();
//        execute.StudentDocumentUploadImg();
//        ManageTransport.UploadDocument7.click();
//        execute.StudentDocumentUploadImg();
//        ManageTransport.ClickAddVehicle.click();
//        Thread.sleep(2000);
//        ManageTransport.VehicleSuccessMsg.click();
        String title=driver.getTitle();
        Assert.assertEquals(Expected, title);
       
    }
        @Test(priority = (1))
	public void AddVehicleReadData() throws InterruptedException {
        	Thread.sleep(2000);
       WebElement table = driver.findElement(By.xpath("//*[@id=\"DataTables_Table_0\"]"));
       String Actual = null;
       String Expected="TN0220";
        List<WebElement> rows = table.findElements(By.tagName("td"));

        for (int i = 0; i < rows.size()-6; i++) {
            WebElement row = rows.get(i);
          //  System.out.print(row.getText());
           Actual= row.getText();
          Assert.assertEquals(Actual, Expected);
          System.out.println(row.getText());
        }
        System.out.println("successfully data fetched");
		
	}
	
	public void StudentDocumentUpload() throws InterruptedException, AWTException {
		PageFactory.initElements(driver, ManageTransport.class);
		Thread.sleep(3000);
		String filePath = "C:\\Users\\User\\Desktop\\School_img\\blank-pdf-document-for-download.pdf";
		StringSelection selection = new StringSelection(filePath);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		ManageTransport.ImgUploadSuccess.click();
	}
	public void StudentDocumentUploadImg() throws InterruptedException, AWTException {
		PageFactory.initElements(driver, ManageTransport.class);
		Thread.sleep(3000);
		String filePath = "C:\\Users\\User\\Desktop\\School_img\\school.jpg";
		StringSelection selection = new StringSelection(filePath);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	}

	 @DataProvider(name="ManageTransport")
		public String[] ReadCreateClass() throws IOException, ParseException {
			JSONParser jsonparser= new JSONParser();
			FileReader reader= new FileReader(".\\Jasonfile\\TransportManagement.json");
			Object obj=jsonparser.parse(reader);
			JSONObject dashBoardloginObj=(JSONObject)obj;
			JSONArray EmployeeWorkingTimeArray=(JSONArray) dashBoardloginObj.get("TransportManagement");
			String arr[]=new String[EmployeeWorkingTimeArray.size()];	
			for(int i=0;i<EmployeeWorkingTimeArray.size();i++) {
				JSONObject empedit=(JSONObject)EmployeeWorkingTimeArray.get(i);
				String VehicleId=(String) empedit.get("VehicleId");
				String RegistrationNo=(String) empedit.get("RegistrationNo");
				String VehicleBoughtOn=(String) empedit.get("VehicleBoughtOn");
				String VehicleModel=(String) empedit.get("VehicleModel");
				String GpsId=(String) empedit.get("GpsId");
				String TotalCapacity=(String) empedit.get("TotalCapacity");
				String FcNo=(String) empedit.get("FcNo");
				String FcStartDate=(String) empedit.get("FcStartDate");
				String FcEndDate=(String) empedit.get("FcEndDate");
				String TotalFcDone=(String) empedit.get("TotalFcDone");
				String InsuranceNo=(String) empedit.get("InsuranceNo");
				String CurrentInsuranceDate=(String) empedit.get("CurrentInsuranceDate");
				String CurrentInsurancEndDate=(String) empedit.get("CurrentInsurancEndDate");
				arr[i]=VehicleId+","+RegistrationNo+","+VehicleBoughtOn+","+VehicleModel+","+GpsId
						+","+TotalCapacity+","+FcNo+","+FcStartDate+","+FcEndDate+","+TotalFcDone+","+InsuranceNo
						+","+CurrentInsuranceDate+","+CurrentInsurancEndDate;
			}
			return arr;
		}
      @Test(priority = (2),dataProvider="ManageTransporting")
	 public void ClickRoutes(String datas) throws InterruptedException, AWTException {
         String Expected ="Manage Transport";
		 Robot robot=new Robot();
		 String user[]= datas.split(",");
		 PageFactory.initElements(driver, ManageTransport.class);
		 ManageTransport.AddRoute.click();
//		 Thread.sleep(2000);
//		 ManageTransport.CreateAddRoute.click();
//		 Thread.sleep(1000);
//		 ManageTransport.RouteName.sendKeys(user[0]);
//		 ManageTransport.ChooseBus.click();
//		 ManageTransport.TripStartTime.sendKeys(user[1]);
//		 ManageTransport.StartingPoint.sendKeys(user[2]);
//		 ManageTransport.EndingPoint.sendKeys(user[3]);
//		 ManageTransport.Driver.click();
//		 ManageTransport.CareTaker.click();
//		 ManageTransport.FeeAmount.sendKeys(user[4]);
//		 ManageTransport.Location.sendKeys(user[5]);
//		 ManageTransport.ArrivingTime.sendKeys(user[6]);
//		 robot.keyPress(KeyEvent.VK_ENTER);
//		 robot.keyRelease(KeyEvent.VK_ENTER);
//		 ManageTransport.Gps.click();
//		 Thread.sleep(2000);
//		 ManageTransport.ClickSearch.sendKeys(user[7]);
//		 robot.keyPress(KeyEvent.VK_ENTER);
//		 robot.keyRelease(KeyEvent.VK_ENTER);
//		 ManageTransport.ClickSubmitBtn.click();
//		 Thread.sleep(2000);
//		 ManageTransport.SubmitBtn.click();
//		 Thread.sleep(2000);
//		 ManageTransport.SuccessBtn.click();
//		 
		 String title=driver.getTitle();
	        Assert.assertEquals(Expected, title);
	 }
      
      @Test(priority = (3))
  	public void AddRouteReadData() throws InterruptedException {
          	Thread.sleep(2000);
         WebElement table = driver.findElement(By.xpath("//*[@id=\"DataTables_Table_2\"]"));
         String Actual = null;
         String Expected="velachery";
          List<WebElement> rows = table.findElements(By.tagName("td"));

          for (int i = 0; i < rows.size(); i++) {
              WebElement row = rows.get(i);
            //  System.out.print(row.getText());
             Actual= row.getText();
            Assert.assertEquals(Actual,Expected);
            System.out.println(row.getText());
          }
          System.out.println("successfully data fetched");
  		logger.info("TC08 - Fetching UserId And Password From Inbox Message");
  		logger.info("Successfully data Fetched");
  		
  	}
      
	 @DataProvider(name="ManageTransporting")
		public String[] ReadCreateRoute() throws IOException, ParseException {
			JSONParser jsonparser= new JSONParser();
			FileReader reader= new FileReader(".\\Jasonfile\\TransportManagement.json");
			Object obj=jsonparser.parse(reader);
			JSONObject dashBoardloginObj=(JSONObject)obj;
			JSONArray EmployeeWorkingTimeArray=(JSONArray) dashBoardloginObj.get("AddRoute");
			String arr[]=new String[EmployeeWorkingTimeArray.size()];	
			for(int i=0;i<EmployeeWorkingTimeArray.size();i++) {
				JSONObject empedit=(JSONObject)EmployeeWorkingTimeArray.get(i);
				String RouteName=(String) empedit.get("RouteName");
				String TripStartTime=(String) empedit.get("TripStartTime");
				String StartingPoint=(String) empedit.get("StartingPoint");
				String EndingPoint=(String) empedit.get("EndingPoint");
				String FeeAmount=(String) empedit.get("FeeAmount");
				String Location=(String) empedit.get("Location");
				String ArrivingTime=(String) empedit.get("ArrivingTime");
				String SearchBar=(String) empedit.get("SearchBar");
				arr[i]=RouteName+","+TripStartTime+","+StartingPoint+","+EndingPoint+","+FeeAmount
						+","+Location+","+ArrivingTime+","+SearchBar;
			}
			return arr;
		}
//	 @Test(priority = (3))
//	 public void StudentMapping() throws InterruptedException {
//		 PageFactory.initElements(driver,ManageTransport.class);
//		 Thread.sleep(2000);
//		 ManageTransport.StudentMapping.click();
//		 Thread.sleep(2000);
//		 ManageTransport.ViewStudent.click();
//		 Thread.sleep(2000);
//		 ManageTransport.SelectStudent.click();
//		 Thread.sleep(1000);
//		 ManageTransport.ChooseLocation.click();
//		 ManageTransport.ClickAddStudent.click();
//		 ManageTransport.AddStudent.click();
//		 Thread.sleep(2000);
//		 ManageTransport.AddSuccessMsg.click(); 
//	 }
//	 @Test(priority = (4))
//	 public void DeleteStudentMapping() throws InterruptedException {
//		 PageFactory.initElements(driver, ManageTransport.class);
//		 Thread.sleep(2000);
//		 ManageTransport.ClickDeleteLogo.click();
//		 Thread.sleep(2000);
//		 ManageTransport.ConfirmationMsg.click();
//		 Thread.sleep(2000);
//		 ManageTransport.DeleteSuccessMsg.click();
	// }
}

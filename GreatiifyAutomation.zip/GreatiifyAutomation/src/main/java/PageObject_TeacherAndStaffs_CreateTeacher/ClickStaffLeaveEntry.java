package PageObject_TeacherAndStaffs_CreateTeacher;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClickStaffLeaveEntry {
	@FindBy(xpath = "//*[@id=\"sideLeaveEntry\"]/a/span")
    public static WebElement ClickStaffLeaveEntry ;
	@FindBy(xpath = "/html/body/div[1]/main/div[2]/div/div[2]/div/div/div[2]/div[2]/button")
	public static WebElement ClickAddLeave;
	@FindBy(xpath = "//*[@id=\"leave_entry\"]/div/div/div[2]/div[2]/div[1]/div[1]/select")
	public static WebElement ClickSelectStaff;
	@FindBy(xpath = "//*[@id=\"leave_entry\"]/div/div/div[2]/div[2]/div[1]/div[1]/select/option[2]")
	public static WebElement ChooseStaff;
	@FindBy(xpath = "//*[@id=\"leave_entry\"]/div/div/div[2]/div[2]/div[1]/div[2]/select")
	public static WebElement ChooseLeaveType;
	@FindBy(xpath = "//*[@id=\"leave_entry\"]/div/div/div[2]/div[2]/div[1]/div[2]/select/option[3]")
	public static WebElement SelectLeaveType;
	@FindBy(xpath = "//*[@id=\"form_date\"]")
	public static WebElement EnterFromDate;
	@FindBy(xpath = "//*[@id=\"to_date\"]")
	public static WebElement EnterToDate;
	@FindBy(css = "#leave_entry > div > div > div.modal-body > div:nth-child(3) > textarea")
	public static WebElement Reason;
	@FindBy(xpath = "//*[@id=\"leave_entry\"]/div/div/div[3]/button[2]")
	public static WebElement Submit;
	@FindBy(css = "body > div.swal-overlay.swal-overlay--show-modal > div > div.swal-footer > div > button")
	public static WebElement SubmitSuccess;
	//EDIT STAFF LEAVE ENTRY
	@FindBy(css = "#DataTables_Table_0 > tbody > tr > td:nth-child(7) > div.edit_text > svg")
	public static WebElement ClickEditLogo;
	@FindBy(xpath = "//*[@id=\"leave_entry_edit\"]/div/div/div[2]/div[1]/div[1]/div/select/option[2]")
	public static WebElement LeaveType;
	@FindBy(xpath = "//*[@id=\"form_date_edit\"]")
	public static WebElement EditFromDate;
	@FindBy(xpath = "//*[@id=\"to_date_edit\"]")
	public static WebElement EditToDate;
	@FindBy(xpath = "//*[@id=\"leave_entry_edit\"]/div/div/div[2]/div[2]/textarea")
	public static WebElement EditReason;
	@FindBy(xpath = "//*[@id=\"leave_entry_edit\"]/div/div/div[3]/button[2]")
	public static WebElement EditClickUpdate;
	@FindBy(xpath = "/html/body/div[5]/div/div[4]/div/button")
	public static WebElement EditSuccess;
	//DELETE STAFF LEAVE ENTRY
	@FindBy(css = "#DataTables_Table_0 > tbody > tr > td:nth-child(7) > div.delete_text > svg")
	public static WebElement ClickDeleteLogo;
	@FindBy(xpath = "/html/body/div[5]/div/div[3]/div[2]/button")
	public static WebElement ClickDeleteConfirmationBtn;
	@FindBy(xpath = "/html/body/div[5]/div/div[4]/div/button")
	public static WebElement DeleteSuccessBtn;
	//CREATE NON TEACHING STAFF ENTRY
	@FindBy(css = "#leave_entry > div > div > div.modal-body > div:nth-child(1) > div > p:nth-child(2) > label")
	public static WebElement ClickNonteachingCat;
}

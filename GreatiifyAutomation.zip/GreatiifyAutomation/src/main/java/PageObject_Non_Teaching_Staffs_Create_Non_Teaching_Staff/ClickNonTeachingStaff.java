package PageObject_Non_Teaching_Staffs_Create_Non_Teaching_Staff;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClickNonTeachingStaff {
	@FindBy(xpath = "//*[@id=\"sideNonTeaching\"]/a/span")
	public static WebElement ClickNonTeachingStaffBtn;
		
}


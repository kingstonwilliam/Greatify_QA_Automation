package TestNgPractice;

import org.testng.annotations.Test;

public class bikeModels {

	@Test(groups= {"inclActiva"})
	public void honda() {
		System.out.println("honda");
	}

	@Test(groups= {"inclActiva"})
	public void honda2() {
		System.out.println("honda");
	}

	@Test

	public void pulsar() {
		System.out.println("pulsar");
	}

	@Test

	public void pulsar2() {
		System.out.println("pulsar");
	}

	@Test

	public void activa() {
		System.out.println("activa");
	}

	@Test

	public void activa2() {
		System.out.println("activa");
	}

	@Test

	public void suzuki() {
		System.out.println("suzuki");
	}

	@Test

	public void suzuki2() {
		System.out.println("suzuki");
	}

}

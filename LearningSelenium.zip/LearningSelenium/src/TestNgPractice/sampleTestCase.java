package TestNgPractice;

import org.testng.annotations.Test;

public class sampleTestCase {
	@Test
  public void TestCase1() {
	  System.out.println("one");
  }	@Test

	  public void TestCase2() {
		  System.out.println("two");
	  }	@Test

		  public void TestCase3() {
			  System.out.println("three");
		  }	@Test

			  public void TestCase4() {
				  System.out.println("four");
			  }  	@Test

				  public void TestCase5() {
					  System.out.println("five");  
  }
}
